<?php
ini_set('session.gc_maxlifetime', 3600*24*7);
session_set_cookie_params(3600*24*7);
session_start();
$keys = array('tmprQyqjkwyahaADHGN');
if(isset($_GET['key'])){
    if(in_array($_GET['key'],$keys))
        $_SESSION['key'] = $_GET['key'];
}
if(!isset($_SESSION['key']) || !in_array($_SESSION['key'],$keys)){
	header('HTTP/1.0 404 Not Found');
	header('Location: https://csgofall.com');
	exit;
}
$db = new PDO('mysql:dbname=csgofall;host=127.0.0.1', 'csgofall', 'I>g^6zK.Mjrv!d^?', array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
$types = ['Withdraw','Pending Withdraw','Deposit','Pending Deposit'];

//CHECK ADMIN AUTH

if(isset($_POST['action'])){
    switch($_POST['action']){
        case 'chat_ban':
            $uid = $db->prepare("SELECT id FROM users WHERE steamid=?");
            $uid->execute(array($_POST['value']));
            $uid = $uid->fetchColumn();
            foreach($db->query("SELECT id,message FROM chat")->fetchAll() as $message)
                if(json_decode($message['message'])->uid == $uid)
                    $db->query("DELETE FROM chat WHERE id=".$message['id']);
            $db->prepare("UPDATE users SET banned = NOT banned WHERE steamid=?")->execute(array($_POST['value']));
            break;
		case 'limit':
            $db->prepare("UPDATE users SET limited = NOT limited WHERE steamid=?")->execute(array($_POST['value']));
            break;
		case 'delete':
            $res = $db->prepare("SELECT id FROM users WHERE steamid=?");
            $res->execute(array($_POST['value']));
            $id = $res->fetchColumn();
            $db->query("DELETE FROM games WHERE uid=$id");
            $db->query("DELETE FROM notifications WHERE uid=$id");
            $db->query("DELETE FROM series WHERE uid=$id");
            $db->query("DELETE FROM codes WHERE uid=$id");
            $db->query("DELETE FROM users WHERE id=$id");
		    break;
        case 'val_switch':
            $db->prepare("UPDATE settings SET value= NOT value WHERE keyname=?")->execute(array($_POST['value']));
            break;
        case 'update_set':
            $db->prepare("UPDATE settings SET value=? WHERE keyname=?")->execute(array($_POST['value'],$_POST['value2']));
            break;
        case 'ajax_load_users':
            $limit = (int)$_POST['limit'];
            $cond = !empty($_POST['cond']) ? "WHERE username LIKE :cond OR steamid LIKE :cond" : "";
            $res = $db->prepare("SELECT id,steamid,username,balance,online,banned,limited,icon FROM users $cond ORDER BY id DESC LIMIT $limit,8");
            $res->execute(array(':cond'=>'%'.$_POST['cond'].'%'));
            foreach($res->fetchAll() as $row){
                ?>
                <tr>
                    <td><?php echo $row['steamid'];?></td>
                    <td><?php echo htmlspecialchars($row['username'],ENT_QUOTES);?></td>
                    <td><?php echo $row['balance'];?> ($<?php echo credits2money($row['balance']);?>)</td>
                    <td><?php echo ((time()-600) < $row['online'])?'Yes':'No';?></td>
                    <td><?php echo $row['banned']?'Yes':'No';?></td>
                    <td><?php echo $row['limited']?'Yes':'No';?></td>
                    <td><button onclick="window.open('betting.php?id=<?php echo $row['id'];?>')">Check</button></td>
                    <td><button onclick="window.open('transaction.php?id=<?php echo $row['id'];?>')">Check</button></td>
                    <td><button onclick="revbalance(<?php echo $row['id'];?>,<?php echo $row['balance'];?>)">SET</button></td>
                    <td><button onclick="revicon(<?php echo $row['id'];?>,'<?php echo $row['icon'];?>')">SET</button></td>
                </tr>
<?php
            }
            break;
        case 'ajax_load_transactions':
            $limit = (int)$_POST['limit'];
            $cond = !empty($_POST['cond']) ? "WHERE n.offer LIKE :cond OR u.username LIKE :cond OR u.steamid LIKE :cond" : "";
            $res = $db->prepare("SELECT u.steamid,u.username,n.type,n.time,n.value,n.offer,n.bot FROM notifications n INNER JOIN users u ON u.id=n.uid $cond ORDER BY n.id DESC LIMIT $limit,10");
            $res->execute(array(':cond'=>'%'.$_POST['cond'].'%'));
            foreach($res->fetchAll() as $row){
                ?>
                <tr>
                    <td><?php echo $row['steamid'];?></td>
                    <td><?php echo $row['username'];?></td>
                    <td><?php echo $types[$row['type']];?></td>
                    <td><?php echo date('H:i:s d/m/Y',$row['time']);?></td>
                    <td><?php echo $row['value'];?> ($<?php echo credits2money($row['type']<2?($row['value']/105)*100:($row['value']/95)*100);?>)</td>
                    <td><?php echo $row['offer'] .' (Bot '.($row['bot']+1).')';?></td>
                </tr>
                <?php
            }
            break;
        case 'ajax_load_codes':
            $limit = (int)$_POST['limit'];
            $cond = !empty($_POST['cond']) ? "WHERE n.code LIKE :cond OR u.username LIKE :cond" : "";
            $res = $db->prepare("SELECT u.username,n.id,n.code,n.earned,n.value,n.claimed FROM codes n INNER JOIN users u ON u.id=n.uid $cond ORDER BY n.id DESC LIMIT $limit,4");
            $res->execute(array(':cond'=>'%'.$_POST['cond'].'%'));
            foreach($res->fetchAll() as $row){
                ?>
                <tr>
                    <td><?php echo $row['code'];?></td>
                    <td><?php echo $row['username'];?></td>
                    <td><?php echo $row['value'];?></td>
                    <td><?php echo $row['earned'];?></td>
                    <td><?php echo $row['claimed'];?></td>
                    <td><button onclick="revcode(<?php echo $row['id'];?>,<?php echo $row['value'];?>)" style="margin-bottom:10px;">SET VALUE</button><button onclick="delcode(<?php echo $row['id'];?>)">DELETE</button></td>
                </tr>
                <?php
            }
            break;
        case 'delete_code':
            $db->prepare("DELETE FROM codes WHERE id=?")->execute(array($_POST['value']));
            break;
        case 'update_code':
            $db->prepare("UPDATE codes SET value=? WHERE id=?")->execute(array((int)$_POST['value'],$_POST['value2']));
            break;
        case 'update_balance':
            $db->prepare("UPDATE users SET balance=? WHERE id=?")->execute(array((int)$_POST['value'],$_POST['value2']));
            break;
        case 'update_icon':
            if(ctype_alnum($_POST['value']) || strlen($_POST['value'])<1)
                $db->prepare("UPDATE users SET icon=? WHERE id=?")->execute(array($_POST['value'],$_POST['value2']));
            break;
    }
}

function credits2money($credits){
    return number_format($credits/1000,2,'.',',');
}
