<?php
set_time_limit(0);
ini_set('display_errors',1);
include('Net/SSH2.php');

$ssh = new Net_SSH2('149.202.192.92');
if (!$ssh->login('root', '7K2mSG379Ahu')) {
    exit('Login Failed');
}
for($i=8121;$i<=8150;$i++)
{
	$ssh->exec("screen -d -m nodejs /var/www/server/csgofall.js $i");
	sleep(5);
}