<?php include 'loader.php';?>
<!DOCTYPE html>
<html lang="en" style="height: 100%;">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Simple Sidebar - Start Bootstrap Template</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/simple-sidebar.css" rel="stylesheet">
    <link href="font-awesome-4.3.0/css/font-awesome.min.css" rel="stylesheet">
</head>

<style>
@import url(https://fonts.googleapis.com/css?family=Ubuntu:400,300,500,700);

*:focus {
outline:none !important;}

body {
    font-family: 'Ubuntu', sans-serif !important;
    background-color: #2a3843;
}

.navbar-default .navbar-brand {
    color: #fff;
    font-weight: bold;
}

.navbar-default {
    background-color: #232f38 !important;
    border: none !important;
}

.navbar-header.fixed-brand {
    background: #f39c12;
}

.navbar-toggle {
    position: relative;
    float: right;
    padding: 6px 10px;
    margin-top: 3.5px;
    margin-left: 10px;
    margin-bottom: 0px;
    background-color: rgba(255, 255, 255, 0);
    background-image: none;
    border: 0px solid rgb(255, 255, 255) !important;
    border-radius: 2px;
    color: #ffffff;
    font-size: 20px;
}

#sidebar-wrapper {
    background: #26333e !important;
}

.sidebar-nav li a {
    display: block;
    text-decoration: none;
    color: rgba(255, 255, 255, 0.26);
    text-transform: uppercase;
    font-weight: bold;
    padding: 5px;
}

.nav-pills>li.active>a, .nav-pills>li.active>a:focus, .nav-pills>li.active>a:hover {
    color: #fff;
    background-color: #374956;
    border-radius: 0px !important;
}
.sidebar-nav {
    margin-top: 0px;
}

.sidebar-nav li a:hover {
    border-left: none !important;
    border-right: 2px solid #fff;
    border-radius: 0px !important;
}

.fa-stack-1x, .fa-stack-2x {
    position: absolute;
    left: -5px;
    width: 100%;
    text-align: center;
}

.user-search input {
    width: 100%;
    border: none;
    padding: 20px;
    background: #232f38;
    display: block;
    margin: 0 auto;
    padding-left: 15px;
    padding-right: 40px;
}

.user-search input::-webkit-input-placeholder {
color:#fff;
}

.user-search input:-moz-placeholder { /* Firefox 18- */
color:#fff;
}

.user-search input::-moz-placeholder {  /* Firefox 19+ */
color:#fff;
}

.user-search input:-ms-input-placeholder {  
color:#fff;
}

.user-search i {
    right: 12px;
    position: absolute;
    top: 21px;
    color: #ffffff;
    font-size: 18px;
}

.stats-container h2 {
    font-weight: bold;
    color: #f39c12;
    font-size: 20px;
    margin-top: 0px;
}

.stats-container p {
    font-weight: bold;
    color: #fff;
    font-size: 12.5px;
    text-transform: uppercase;
	margin-bottom:0px;
}

.stats-container {
    background: #26333e;
    padding: 10px;
    margin-top: 0px;
    border-radius: 2px;
}

.withdraw-server h2 {
    margin-top: 0px;
    color: #fff;
    font-size: 16px;
    text-transform: uppercase;
    padding: 5px;
    border-radius: 2px;
	padding-left:0px;
}

.withdraw-server {
    background: #26333e;
    padding: 10px;
    margin-top: 20px;
    border-radius: 2px;
}

.withdraw-server input {
    border-radius: 2px;
    width: 100%;
    border: none;
    padding: 10px;
    background: #232f38;
}

span#serverbal {
    floaT: right;
    color: #f39c12;
    font-weight: bold;
}

input:focus {
    background: #1c262d;
}

.nav-stacked>li+li {
    margin-top: 0px;
    margin-left: 0;
}

.withdraw-server p {
    color: #ffffff;
    background: #2a3843;
    padding: 10px;
    border-radius: 2px;
}

.withdraw-server button {
    width: 100px;
    padding: 10px;
    margin-top: 10px;
    border: none;
    border-radius: 2px;
    font-weight: bold;
    text-transform: uppercase;
    font-size: 12px;
    color: #fff;
    background-color: #f39c12;
    display: block;
    margin-left: auto;
}

.withdraw-server h4 {
    font-size: 12px;
    color: #fff;
    font-weight: bold;
    margin-top: 20px;
}

/* The switch - the box around the slider */
.switch {
    position: relative;
    display: inline-block;
    width: 52px;
    height: 25px;
    vertical-align: middle;
    margin-bottom: 0px !important;
    float: right;
    margin-top: 5px;
    margin-right: 5px;
}

/* Hide default HTML checkbox */
.switch input {display:none;}

/* The slider */
.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #ccc;
  -webkit-transition: .4s;
  transition: .4s;
}

.slider:before {
    position: absolute;
    content: "";
    height: 17px;
    width: 17px;
    left: 4px;
    bottom: 4px;
    background-color: white;
    -webkit-transition: .4s;
    transition: .4s;
}

input:checked + .slider {
    background-color: #f39c12;
}

input:focus + .slider {
  box-shadow: 0 0 1px #2196F3;
}

input:checked + .slider:before {
  -webkit-transform: translateX(26px);
  -ms-transform: translateX(26px);
  transform: translateX(26px);
}

/* Rounded sliders */
.slider.round {
    border-radius: 7px;
}

.slider.round:before {
  border-radius: 7px;
}

.global-settings h4 {
    color: #fff;
    font-size: 16px;
    padding: 10px;
    margin: 0px;
    display: inline-block;
}

.global-settings {
    background: #26333e;
    margin-top: 20px;
}

.switch-cont {
    padding: 10px;
}

.switch-cont h4 strong {
    font-size: 10px;
    color: #506675;
	margin-left:10px;
}
.table-logs h2 {
    margin: 0px;
	margin-bottom:20px;
    color: #fff;
}

.table-striped>tbody>tr:nth-of-type(odd) {
    background-color: transparent;
}

.table>tbody>tr>td, .table>tbody>tr>th, .table>tfoot>tr>td, .table>tfoot>tr>th, .table>thead>tr>td, .table>thead>tr>th {
    padding: 15px;
    line-height: 1.42857143;
    vertical-align: top;
    border-top: 0px solid #ddd;
    border-bottom: 1px solid #374956;
    font-weight: bold;
}

.table>thead>tr>th {
    vertical-align: bottom;
    border-bottom: 0px solid #ddd;
    background: #27343e;
}

table.table.table-striped {
    color: #fff;
}

.user-search-page input {
    margin-bottom: 20px;
    border-radius: 2px;
    width: 100%;
    border: none;
    padding: 15px;
    background: #232f38;
    display: block;
    padding-left: 15px;
    padding-right: 40px;
    font-size: 18px;
}
.user-search-page i {
    right: 33px;
    position: absolute;
    top: 34px;
    color: #ffffff;
    font-size: 25px;
}
button {
    width: 100px;
    padding: 10px;
    border: none;
    border-radius: 2px;
    font-weight: bold;
    text-transform: uppercase;
    font-size: 12px;
    color: #fff;
    background-color: #f39c12;
    display: block;
}
input {
	color:white;
}
</style>

<body  style="height: 100%;">
    <nav class="navbar navbar-default no-margin">
    <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header fixed-brand">
                    <button type="button" class="navbar-toggle collapsed men-tog" data-toggle="collapse"  id="menu-toggle">
                      <span class="glyphicon glyphicon-th-large" aria-hidden="true"></span>
                    </button>
                    <a class="navbar-brand" href="#"><i class="fa fa-adjust" aria-hidden="true"></i> CSGOFall</a>        
                </div><!-- navbar-header-->

                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                            <ul class="nav navbar-nav">
                                <li class="active" ><button class="navbar-toggle collapse in" data-toggle="collapse" id="menu-toggle-2"> <i class="fa fa-bars" aria-hidden="true"></i></button></li>
                            </ul>
                </div><!-- bs-example-navbar-collapse-1 -->
    </nav>
    <div id="wrapper"  style="height: 100%;">
        <!-- Sidebar -->
        <div id="sidebar-wrapper">
          <ul class="sidebar-nav nav-pills nav-stacked" id="menu">		
			<div id="usrsr" class="user-search">
				
			</div>
                <li>
                    <a href="index.php"><span class="fa-stack fa-lg pull-left"><i class="fa fa-dashboard fa-stack-1x "></i></span> Dashboard</a>
                </li>
                <li>
                    <a href="users.php"><span class="fa-stack fa-lg pull-left"><i class="fa fa-user fa-stack-1x "></i></span>Users</a>
                </li>
                <li>
                    <a href="affiliates.php"><span class="fa-stack fa-lg pull-left"><i class="fa fa-user-plus fa-stack-1x "></i></span>Affiliates</a>
                </li>
                <li class="active">
                    <a href="transactions.php"><span class="fa-stack fa-lg pull-left"><i class="fa fa-cloud-download fa-stack-1x "></i></span>Transactions</a>
                </li>
                <li>
                    
                </li>
                <li>
                    
                </li>
                <li>
                    
                </li>
                <li>
                    <a href="settings.php"><span class="fa-stack fa-lg pull-left"><i class="fa fa-server fa-stack-1x "></i></span>SETTINGS</a>
               </li>
          </ul>
        </div>
        <!-- Page Content -->
        <div id="page-content-wrapper"  style="height: 100%;">

        <div class="user-search-page">
			<input placeholder="Search by Username, Steam ID or Offer ID" onkeyup="ajaxLoad(-1)"> </input><i class="fa fa-search" aria-hidden="true"></i>
		</div>
		
        <div class="table-logs">
		  <table class="table table-striped">
			<thead>
			  <tr>
			    <th>Steam ID</th>
				<th>Username</th>
				<th>Type</th>
				<th>Date</th>
				<th>Total</th>
				<th>Offer ID</th>
			  </tr>
			</thead>
			<tbody id="ajax_content">
			</tbody>
		  </table>
		  <button style="float:left;margin-right:10px;" onclick='ajaxLoad(0)'>Back</button><button style="float:left;" onclick='ajaxLoad(1)'>Next</button>
		</div>
		
		<div class="row">
			<div class="col-lg-3">
				<div class="analytics-boxes">
					
				</div>
			</div>
		</div>
        <!-- /.row -->


        </div>
        <!-- /#page-content-wrapper -->

    </div>
    <!-- /#wrapper -->
    <!-- jQuery -->
    <script src="js/jquery-1.11.2.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/sidebar_menu.js"></script>
	
<script>
var limit = 0;
function ajaxLoad(type){
	if(type>0) 
		limit += 10;
	else if(type > -1)
		limit -= 10;
	if(limit < 0) limit = 0;
	$.post('loader.php',{action:'ajax_load_transactions',limit:limit,cond:$('input[placeholder="Search by Username, Steam ID or Offer ID"]').val()},function(resp){
		$('#ajax_content').html(resp);
	});
}
ajaxLoad(-1);
</script>



</body>

</html>
