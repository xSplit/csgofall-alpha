<?php
include 'loader.php';

if(isset($_GET['id'])){
    $res = $db->prepare("SELECT type,value,time,offer,bot FROM notifications WHERE uid=? ORDER BY id DESC");
    $res->execute(array($_GET['id']));
    foreach($res->fetchAll() as $n)
        echo 'Type: '.$types[$n['type']].'<br>Credits: '.$n['value'].' ($'.credits2money($n['type']<2?($n['value']/105)*100:($n['value']/95)*100).')<br>Offer: '
            .$n['offer'].' (Bot '.($n['bot']+1).')<br>Date: '.date('H:i:s d/m/Y',$n['time']).'<br><br>';
}