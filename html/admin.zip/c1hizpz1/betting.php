<?php
include 'loader.php';

if(isset($_GET['id'])){
    $res = $db->prepare("SELECT mul,bet,color,time FROM games WHERE uid=? ORDER BY id DESC");
    $res->execute(array($_GET['id']));
    $coins = ['Yellow','Green','Red','Dice'];
    foreach($res->fetchAll() as $bet)
        echo 'Bet: '.$bet['bet'].'<br>Result: x'.$bet['mul'].'<br>Coin: '.($bet['color']>=0?$coins[$bet['color']]:'Dice '.(-$bet['color']-1)).'<br>Date: '.date('H:i:s d/m/Y',$bet['time']).'<br><br>';
}